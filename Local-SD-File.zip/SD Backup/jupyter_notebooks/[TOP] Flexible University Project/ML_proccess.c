#include "ML_proccess.h"
bool* ML_proccess(bool* ifmaps, bool* weight, short* bias, int kernel_size, int input_ch, int output_ch, int stride, int function, int ifmaps_width, int ofmaps_width)
{
    bool* ofmaps = malloc(ofmaps_width * ofmaps_width * output_ch * sizeof(int));
    if(function == 0)
    {   
        for (int o_ch = 0; o_ch < output_ch; o_ch++)
        {
            for (int o_h = 0; o_h < ofmaps_width; o_h++)
            {
                for (int o_w = 0; o_w < ofmaps_width; o_w++)
                {
                    int psum = 0;
                    for (int w_h = 0; w_h < kernel_size; w_h++)
                    {
                        for (int w_w = 0; w_w < kernel_size; w_w++)
                        {
                            int h = o_h * stride + w_h;
                            int w = o_w * stride + w_w;
                            for (int ch = 0; ch < input_ch; ch++)
                            {
                                int tmp = (!(bool)(ifmaps[ch*ifmaps_width*ifmaps_width+h*ifmaps_width+w] ^ weight[o_ch*input_ch*kernel_size*kernel_size+ch*kernel_size*kernel_size+w_h*kernel_size+w_w])) ? 1 : -1;
                                psum += tmp;
                            }
                        }
                    }
                    psum = psum + bias[o_ch];
                    ofmaps[o_ch*ofmaps_width*ofmaps_width+o_h*ofmaps_width+o_w] = ((psum >= 0) ? 1 : 0);
                }
            }
        }
    }
    else
    {
        for (int o_ch = 0; o_ch < input_ch; o_ch++)
        {
            for (int o_h = 0; o_h < ofmaps_width; o_h++)
            {
                for (int o_w = 0; o_w < ofmaps_width; o_w++)
                {
                    int flag = 0;
                    for (int w_h = 0; w_h < kernel_size; w_h++)
                    {
                        for (int w_w = 0; w_w < kernel_size; w_w++)
                        {
                            int h = o_h * stride + w_h;
                            int w = o_w * stride + w_w;
                            if (ifmaps[o_ch*ifmaps_width*ifmaps_width+h*ifmaps_width+w] == 1)
                            {
                                flag = 1;
                                break; 
                            }
                        }
                        if (flag == 1)
                            break;
                    }
                    ofmaps[o_ch*ofmaps_width*ofmaps_width+o_h*ofmaps_width+o_w] = flag;
                }
            }
        }
    }
    
    return ofmaps;
}

float* arr_axis_fc_modeling(bool arr[], unsigned int in_features, unsigned int out_features, unsigned int ofmaps_width, unsigned int ifbias, float weight[], float bias[]) {
    float* answer_arr;
    int* tmp_arr;
//     float max_val = 0.0;
//     int answer_idx = 0;
    int size = ofmaps_width * ofmaps_width;
    // tmp_arr = (int *)malloc(in_features * sizeof(int));
    answer_arr = (float *)malloc(out_features * sizeof(float));

    #pragma omp parallel for
    for (int i = 0; i < out_features; i++) {
        float sum = 0;
        int limit = i * in_features;

        #pragma omp parallel for reduction(+:sum)
        for (int j = 0; j < in_features; j++) {
            // �ˬd tmp_arr[j] �O�_�� 0 �� 1�A�ì����a�վ��v���]-1 �� 1�^
            sum += arr[j] ? weight[limit + j] : -weight[limit + j];
        }

        if (ifbias)
            answer_arr[i] = sum + bias[i];
    }

    float sum_exp = 0.0;

    // �p�� exp
    #pragma omp parallel for reduction(+:sum_exp)
    for (int i = 0; i < out_features; i++) {
        answer_arr[i] = exp(answer_arr[i]);
        sum_exp += answer_arr[i];
    }

    // �p�� softmax
    #pragma omp parallel for
    for (int i = 0; i < out_features; i++) {
        answer_arr[i] /= sum_exp;
    }
  

    return answer_arr;
}

int findMAX(float *arr, int size) {
    float max_val = 0.0;
    int answer_idx = 0;

    // �}�l�p��
//     double start_time = omp_get_wtime();

    #pragma omp parallel for
    for (int i = 0; i < size; i++) {
        #pragma omp critical
        if (arr[i] > max_val) {
            max_val = arr[i];
            answer_idx = i;
        }
    }

    // ����p��
//     double end_time = omp_get_wtime();
//     double total_time = end_time - start_time;
//     printf("��X�̤j�Ȯɶ�: %.4f ��\n", total_time);

    return answer_idx;
}
