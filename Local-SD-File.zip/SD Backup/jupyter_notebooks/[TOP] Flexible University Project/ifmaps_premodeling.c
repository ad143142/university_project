#include<stdio.h>
#include <stdlib.h>

unsigned int* pre_modeling(unsigned int arr[],unsigned int ifmaps_height,unsigned int ifmaps_width,unsigned int ifmaps_channel,unsigned int stride, unsigned int weight_height)
{   
    unsigned int o_channel = (ifmaps_channel+31)/32;
    unsigned int o_hight = ((ifmaps_height - weight_height) / stride) + 1;

    unsigned int* modeling_arr;

    modeling_arr = malloc( o_channel * ifmaps_height * ifmaps_width * sizeof(unsigned int) );
#pragma omp parallel for collapse(2)
    for(int h=0;h<ifmaps_height;h=h+stride)
    {
        for(int w=0;w<ifmaps_width;w++)
        {
            int axis_tmp=0;
            int idx=0;
            for(int ch=0;ch<ifmaps_channel;ch++)
            {
                axis_tmp |= arr[ch*ifmaps_width*ifmaps_height+h*ifmaps_width+w]<<idx;
                idx = idx + 1;

                if((ch % 32 == 31) || (ch == ifmaps_channel-1))
                {
                    modeling_arr[ch/32*ifmaps_width*ifmaps_height+h*ifmaps_width+w] = axis_tmp;
                    axis_tmp=0;
                    idx=0;
                }
                    
            }
        }
    }

    return modeling_arr;
}

void free_mem(unsigned int *ptr)
{
    free(ptr);
}
/*
o_hight = int(((ifmaps_hight - weight_height) / stride + 1))
    
    o_channel = (ifmaps_channel+31)//32
    modeling_arr = np.empty((o_channel,ifmaps_hight,ifmaps_width),dtype = np.uint32)
    a = time.time()

    for h in range(0,ifmaps_hight,stride):
        for w in range(ifmaps_width):
            axis_tmp = 0
            idx = 0 
            for ch in range(ifmaps_channel):
                axis_tmp |= file_ifmaps[ch][h][w]<<idx;
                idx = idx + 1
                
                if((ch % 32 == 31) or (ch == ifmaps_channel-1)):
                    modeling_arr[ch//32][h][w] = axis_tmp
                    ifmaps = 0 
                    idx = 0
*/

// int main()
// {
//     unsigned int* file_arr;
//     file_arr = malloc( 3 * 34 * 34 * sizeof(unsigned int) );

//     char *filename = "ifmaps0.txt";
//     FILE *fp = fopen(filename, "r");

//     if (fp == NULL)
//     {
//         printf("Error: could not open file %s", filename);
//         return 1;
//     }

//     // read one character at a time and
//     // display it to the output
//     char ch;
//     int i=0;
//     for(int x=0;x<3*34*34;x++)
//     {
//         fscanf(fp,"%d", &file_arr[x]);
//     }

//     // close the file
//     fclose(fp);

//     // for(int x=0;x<3;x++)
//     // {
//     //     for(int y=0;y<34;y++)
//     //     {
//     //         for(int z=0;z<34;z++)
//     //         {
//     //             printf("%d ",file_arr[x*34*34+y*34+z]);
//     //         }
//     //         printf("\n");
//     //     }
//     //     printf("\n");
//     // }
//     unsigned int *ret_arr;
//     ret_arr = pre_modeling(file_arr,34,34,3,1,3);

//     // printf("%d",sizeof(ret_arr));
//     FILE *f = fopen("ifmaps_modeling.txt", "wb");
//     for(int x=0;x<1;x++)
//     {
//         for(int y=0;y<34;y++)
//         {
//             for(int z=0;z<34;z++)
//             {
//                 fprintf(f,"%d ",ret_arr[x*34*34+y*34+z]);
//             }
//             fprintf(f,"\n");
//         }
//         fprintf(f,"\n");
//     }
//     fclose(f);

//     return 0;
// }