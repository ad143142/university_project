#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <numpy/arrayobject.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>


///////////////////////////////  arr_axis_modeling  ///////////////////////////////
unsigned int* arr_axis_modeling(unsigned int arr[],unsigned int ifmaps_height,unsigned int ifmaps_width,unsigned int ifmaps_channel,unsigned int stride, unsigned int weight_height)
{   
    unsigned int o_hight = ((ifmaps_height - weight_height) / stride) + 1;

    unsigned int* modeling_arr;

    modeling_arr =  (unsigned int *)malloc(ifmaps_channel * o_hight * ifmaps_width * weight_height * sizeof(unsigned int) );

    unsigned int idx = 0;
    unsigned int o_hight_lim = (ifmaps_height - weight_height)+1;
    for(unsigned int h=0;h<o_hight_lim;h=h+stride)
    {
        for(unsigned int i_w=0;i_w<ifmaps_width;i_w++)
        {
            for(unsigned int w_h=0;w_h<weight_height;w_h++)
            {
                for(unsigned int ch=0;ch<ifmaps_channel;ch++)
                {
                    modeling_arr[idx] = arr[ch * ifmaps_height * ifmaps_width + (w_h + h) * ifmaps_width + i_w];
                    idx++;
                }
            }
        }
        
    }

    return modeling_arr;
}

static PyObject *py_arr_axis_modeling(PyObject *self, PyObject *args) {
    PyObject *py_arr;
    unsigned int ifmaps_height, ifmaps_width, ifmaps_channel, stride, weight_height;

    if (!PyArg_ParseTuple(args, "Oiiiii", &py_arr, &ifmaps_height, &ifmaps_width, &ifmaps_channel, &stride, &weight_height)) {
        return NULL;
    }

    PyArrayObject *numpy_arr = (PyArrayObject *)PyArray_FROM_OTF(py_arr, NPY_UINT, NPY_ARRAY_IN_ARRAY);
    if (!numpy_arr) {
        PyErr_SetString(PyExc_TypeError, "Input must be a NumPy array of uint");
        return NULL;
    }
    
    
    unsigned int *arr_data = (unsigned int *)PyArray_DATA(numpy_arr);

    unsigned int *result = arr_axis_modeling(arr_data, ifmaps_height, ifmaps_width, ifmaps_channel, stride, weight_height);

    // freopen("axi_output.txt", "w", stdout);
    // // result print in python
    // for(int i=0;i<ifmaps_channel * (((ifmaps_height - weight_height) / stride) + 1) * ifmaps_width * weight_height;i++)
    // {
    //     printf("%u ",result[i]);
    // }
    // // 添加打印語句來確認解析的參數值
    // printf("\nifmaps_height: %u\n", ifmaps_height);
    // printf("ifmaps_width: %u\n", ifmaps_width);
    // printf("ifmaps_channel: %u\n", ifmaps_channel);
    // printf("stride: %u\n", stride);
    // printf("weight_height: %u\n", weight_height);
    // printf("Result array dimensions: %d\n", PyArray_NDIM(py_result));
    // printf("Result array data type name: %s\n", PyArray_DESCR(py_result)->typeobj->tp_name);
    // fclose(stdout);

    npy_intp dims[1] = {ifmaps_channel * (((ifmaps_height - weight_height) / stride) + 1) * ifmaps_width * weight_height};
    PyObject *py_result = PyArray_SimpleNewFromData(1, dims, NPY_UINT, result);

//     free(numpy_arr);
    Py_DECREF(numpy_arr);
    
//     Py_DECREF(py_arr);
//     PyArray_XDECREF(numpy_arr);  // Decrement the reference count to prevent memory leaks

//     free(arr_data); // for test memory
    
//     free(result); // 千萬不要 free，否則會出錯
 
    return py_result;
}

////////////////arr_axis_fc_modeling//////////////////////////////////

void intToBinary(unsigned int *current_num_ptr, bool *binaryArray, unsigned int start_point, unsigned int block_size, unsigned int stride) {
    for (unsigned int i = 0; i < block_size; i++) {
        unsigned int current_num = *current_num_ptr;
        for (int j = 0; j < 32; j++) {
            *(binaryArray + stride * (j + i * 32) + start_point) = current_num & 1; // 32 bits
            current_num >>= 1;
        }
        current_num_ptr++; // shift to next number
    }
}

float* arr_axis_fc_modeling(unsigned int arr[], unsigned int in_features, unsigned int out_features, unsigned int ofmaps_width, unsigned int ifbias, float weight[], float bias[]) {
    float* answer_arr;
    bool* tmp_arr;
    int size = ofmaps_width * ofmaps_width;
    tmp_arr = (bool *)malloc(in_features * sizeof(bool));
    answer_arr = (float *)malloc(out_features * sizeof(float));
    int block_size = in_features / (size << 5); // 32 bits

    for (unsigned int i = 0; i < (in_features >> 5); i += block_size) {  // shift 5 bits for 32 bits
        intToBinary(&arr[i], tmp_arr, i >> 2, block_size, size);
    }

    for (unsigned int i = 0; i < out_features; i++) {
        float sum = 0;
        int limit = i * in_features;

        for (unsigned int j = 0; j < in_features; j++) {
            // 檢查 tmp_arr[j] 是否為 0 或 1，並相應地調整權重（-1 或 1）
            sum += tmp_arr[j] ? weight[limit + j] : -weight[limit + j];
        }

        if (ifbias)
            answer_arr[i] = sum + bias[i];
    }

    float sum_exp = 0.0;

    // 計算 exp
    for (unsigned int i = 0; i < out_features; i++) {
        answer_arr[i] = expf(answer_arr[i]);
        sum_exp += answer_arr[i];
    }

    // 計算 softmax
    for (unsigned int i = 0; i < out_features; i++) {
        answer_arr[i] /= sum_exp;
    }

    free(tmp_arr);
    return answer_arr;
}

static PyObject *py_arr_axis_fc_modeling(PyObject *self, PyObject *args) {
    PyObject *py_arr;
    unsigned int in_features, out_features, ofmaps_width, ifbias;
    PyObject *py_weight, *py_bias;

    if (!PyArg_ParseTuple(args, "OiiiiOO", &py_arr, &in_features, &out_features, &ofmaps_width, &ifbias, &py_weight, &py_bias)) {
        return NULL;
    }

    PyArrayObject *numpy_arr = (PyArrayObject *)PyArray_FROM_OTF(py_arr, NPY_UINT, NPY_ARRAY_IN_ARRAY);
    if (!numpy_arr) {
        PyErr_SetString(PyExc_TypeError, "Input must be a NumPy array of uint");
        return NULL;
    }

    // Convert py_weight and py_bias to PyArrayObject pointers
    PyArrayObject *py_weight_array = (PyArrayObject *)py_weight;
    PyArrayObject *py_bias_array = (PyArrayObject *)py_bias;

    // Convert PyArrayObject pointers to float pointers
    float *weight = (float *)PyArray_DATA(py_weight_array);
    float *bias = (float *)PyArray_DATA(py_bias_array);
    unsigned int *arr_data = (unsigned int *)PyArray_DATA(numpy_arr);

    // Call the C function arr_axis_fc_modeling
    float *result = arr_axis_fc_modeling(arr_data, in_features, out_features, ofmaps_width, ifbias, weight, bias);

    // Convert the result to a NumPy float array
    npy_intp dims[1] = {out_features};
    PyObject *py_result = PyArray_SimpleNewFromData(1, dims, NPY_FLOAT, result);
    
//     free(numpy_arr);
    Py_DECREF(numpy_arr);
//     Py_DECREF(py_arr);
//     PyArray_XDECREF(numpy_arr);  // Decrement the reference count to prevent memory leaks

//     free(arr_data); // for test memory
//     free(weight); // for test memory
//     free(bias); // for test memory
    
//     free(result); // 千萬不要 free，否則會出錯

    return py_result;
}

/////////////findMAX///////////////////////
int findMAX(float arr[], int size) {
    float max_val = 0.0;
    int answer_idx = 0;

    for (int i = 0; i < size; i++) {
        if (arr[i] > max_val) {
            max_val = arr[i];
            answer_idx = i;
        }
    }

    return answer_idx;
}

static PyObject *py_findMAX(PyObject *self, PyObject *args) {
    PyObject *py_arr;
    int size;

    if (!PyArg_ParseTuple(args, "Oi", &py_arr, &size)) {
        return NULL;
    }

    PyArrayObject *numpy_arr = (PyArrayObject *)PyArray_FROM_OTF(py_arr, NPY_FLOAT, NPY_ARRAY_IN_ARRAY);
    if (!numpy_arr) {
        PyErr_SetString(PyExc_TypeError, "Input must be a NumPy array of float");
        return NULL;
    }

    float *arr_data = (float *)PyArray_DATA(numpy_arr);

    int max_idx = findMAX(arr_data, size);

//     free(numpy_arr);
    Py_DECREF(numpy_arr);
//     Py_DECREF(py_arr);
//     PyArray_XDECREF(numpy_arr);  // Decrement the reference count to prevent memory leaks

//     free(arr_data); // for test memory

    return PyLong_FromLong(max_idx);
}

//////////////pre_modeling/////////////////////
unsigned int* pre_modeling(unsigned int arr[],unsigned int ifmaps_height,unsigned int ifmaps_width,unsigned int ifmaps_channel,unsigned int stride, unsigned int weight_height)
{   
    unsigned int o_channel = (ifmaps_channel+31)/32;
    // unsigned int o_hight = ((ifmaps_height - weight_height) / stride) + 1;

    unsigned int* modeling_arr;

    modeling_arr = (unsigned int *)malloc( o_channel * ifmaps_height * ifmaps_width * sizeof(unsigned int) );
    for(unsigned int h=0;h<ifmaps_height;h=h+stride)
    {
        for(unsigned int w=0;w<ifmaps_width;w++)
        {
            int axis_tmp=0;
            int idx=0;
            for(unsigned int ch=0;ch<ifmaps_channel;ch++)
            {
                axis_tmp |= arr[ch*ifmaps_width*ifmaps_height+h*ifmaps_width+w]<<idx;
                idx = idx + 1;

                if((ch % 32 == 31) || (ch == ifmaps_channel-1))
                {
                    modeling_arr[ch/32*ifmaps_width*ifmaps_height+h*ifmaps_width+w] = axis_tmp;
                    axis_tmp=0;
                    idx=0;
                }
                    
            }
        }
    }

    return modeling_arr;
}

static PyObject *py_pre_modeling(PyObject *self, PyObject *args) {
    PyObject *py_arr;
    unsigned int ifmaps_height, ifmaps_width, ifmaps_channel, stride, weight_height;

    if (!PyArg_ParseTuple(args, "Oiiiii", &py_arr, &ifmaps_height, &ifmaps_width, &ifmaps_channel, &stride, &weight_height)) {
        return NULL;
    }

    PyArrayObject *numpy_arr = (PyArrayObject *)PyArray_FROM_OTF(py_arr, NPY_UINT, NPY_ARRAY_IN_ARRAY);
    if (!numpy_arr) {
        PyErr_SetString(PyExc_TypeError, "Input must be a NumPy array of uint");
        return NULL;
    }

    unsigned int *arr_data = (unsigned int *)PyArray_DATA(numpy_arr);
    unsigned int *result = pre_modeling(arr_data, ifmaps_height, ifmaps_width, ifmaps_channel, stride, weight_height);

    npy_intp dims[1] = {((ifmaps_channel+31)/32) * ifmaps_height * ifmaps_width};
    PyObject *py_result = PyArray_SimpleNewFromData(1, dims, NPY_UINT, result);
    
//     free(numpy_arr);
    Py_DECREF(numpy_arr);
//     Py_DECREF(py_arr);
//     PyArray_XDECREF(numpy_arr);  // Decrement the reference count to prevent memory leaks

    
//     free(arr_data); // for test memory

    return py_result;
}

/////////////////free_mem/////////////////////
void free_mem(unsigned int *ptr)
{
    if (ptr != NULL) {
        free(ptr);
    }
//     free(ptr);
}

static PyObject *py_free_mem(PyObject *self, PyObject *args) {
    PyObject *py_arr;

    if (!PyArg_ParseTuple(args, "O", &py_arr)) {
        return NULL;
    }

    PyArrayObject *numpy_arr = (PyArrayObject *)PyArray_FROM_OTF(py_arr, NPY_UINT, NPY_ARRAY_IN_ARRAY);
    if (!numpy_arr) {
        PyErr_SetString(PyExc_TypeError, "Input must be a NumPy array of uint");
        return NULL;
    }

    unsigned int *arr_data = (unsigned int *)PyArray_DATA(numpy_arr);

    free_mem(arr_data);
    PyArray_XDECREF(numpy_arr);  // Decrement the reference count to prevent memory leaks
    Py_RETURN_NONE;
}


/////////////////free_float_mem/////////////////////
void free_float_mem(float *ptr) {
    if (ptr != NULL) {
        free(ptr);
    }
//     free(ptr);
}

static PyObject *py_free_float_mem(PyObject *self, PyObject *args) {
    PyObject *py_arr;

    if (!PyArg_ParseTuple(args, "O", &py_arr)) {
        return NULL;
    }

    PyArrayObject *numpy_arr = (PyArrayObject *)PyArray_FROM_OTF(py_arr, NPY_FLOAT, NPY_ARRAY_IN_ARRAY);
    if (!numpy_arr) {
        PyErr_SetString(PyExc_TypeError, "Input must be a NumPy array of float");
        return NULL;
    }

    float *arr_data = (float *)PyArray_DATA(numpy_arr);

    free_float_mem(arr_data);
    PyArray_XDECREF(numpy_arr);  // Decrement the reference count to prevent memory leaks
    Py_RETURN_NONE;
}


/////////////////setup/////////////////////

static PyMethodDef methods[] = {
    {"arr_axis_modeling", py_arr_axis_modeling, METH_VARARGS, "Perform axis modeling on a NumPy array"},
    {"arr_axis_fc_modeling", py_arr_axis_fc_modeling, METH_VARARGS, "Perform axis modeling for FC layer on a NumPy array"},
    {"findMAX", py_findMAX, METH_VARARGS, "Find the index of the maximum value in a NumPy float array"},
    {"pre_modeling", py_pre_modeling, METH_VARARGS, "Perform pre-modeling on a NumPy array"},
    {"free_mem", py_free_mem, METH_VARARGS, "Free allocated memory"},
    {"free_float_mem", py_free_float_mem, METH_VARARGS, "Free allocated memory"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef my_module = {
    PyModuleDef_HEAD_INIT,
    "my_module",
    NULL,
    -1,
    methods
};

PyMODINIT_FUNC PyInit_my_module(void) {
    import_array();
    return PyModule_Create(&my_module);
}
