#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define LAYER_NUM 6

typedef struct{
    // unsigned int layer_num;

    unsigned int kernel_size  [LAYER_NUM];
    unsigned int input_ch     [LAYER_NUM];
    unsigned int output_ch    [LAYER_NUM];
    unsigned int stride       [LAYER_NUM];
    unsigned int function     [LAYER_NUM];
    unsigned int ifmaps_width [LAYER_NUM];
    unsigned int ofmaps_width [LAYER_NUM];
    unsigned int out_class   ;
    unsigned int use_fcbias  ;
    
    unsigned int output_array_size [LAYER_NUM];
} global_setting;

global_setting load_global_setting(void);

bool* load_ifmaps(global_setting setting,int layer);

bool* load_weight(global_setting setting,int layer);

short* load_bias(global_setting setting,int layer);

bool* load_ofmaps(global_setting setting,int layer);

bool* ML_proccess(bool* ifmaps, bool* weight, short* bias, int kernel_size, int input_ch, int output_ch, int stride, int function, int ifmaps_width, int ofmaps_width);

int findMAX(float *arr, int size);

float* arr_axis_fc_modeling(bool arr[], unsigned int in_features, unsigned int out_features, unsigned int ofmaps_width, unsigned int ifbias, float weight[], float bias[]);
