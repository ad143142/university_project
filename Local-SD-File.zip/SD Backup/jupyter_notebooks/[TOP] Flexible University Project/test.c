#include<stdio.h>
#include <stdlib.h>

int* array_add_one(int arr[],const unsigned int size)
{
    for(unsigned int x=0;x<size;x++)
    {
        arr[x] = arr[x]+1;
    }

    return arr;
}

// int main()
// {
//     int a[10];
//     int* ret;
//     for(int x=0;x<10;x++)
//     {
//         a[x] = x;
//     }
//     ret = array_add_one(a,10);

//     for(int x=0;x<10;x++)
//     {
//         printf("%d ",ret[x]);
//     }
// }