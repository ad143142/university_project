from distutils.core import setup, Extension

module = Extension("my_module",
                   sources=["my_module.c"],
                   extra_compile_args=['-O3', "-march=native", "-ffast-math"]) # 可以嘗試加 -funroll-loops, -fprofile-guided-optimization, (-ffast-math, -funsafe-math-optimizations)這有風險可能資料匯出錯要嘗試, (-mavx2, -msse4.2, -mfma, -mavx512f)要查datasheet看有沒有指令集， 

setup(name="my_module",
      version="1.0",
      description="My custom module",
      ext_modules=[module]
     )
