#!/bin/bash
# Start FastAPI Server with app.py under FastAPI/ folder
#

# FOR DEBUG ONLY!

. ./testenv/bin/activate
uvicorn main:app --host 0.0.0.0 --port 8000