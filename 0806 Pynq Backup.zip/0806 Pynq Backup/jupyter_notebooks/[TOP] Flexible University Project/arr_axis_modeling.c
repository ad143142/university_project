#include<stdio.h>
#include <stdlib.h>
// #include <string.h>
// #include <time.h>
#include <omp.h>
#include <math.h>

unsigned int* arr_axis_modeling(unsigned int arr[],unsigned int ifmaps_height,unsigned int ifmaps_width,unsigned int ifmaps_channel,unsigned int stride, unsigned int weight_height)
{   
    unsigned int o_hight = ((ifmaps_height - weight_height) / stride) + 1;

    unsigned int* modeling_arr;

    modeling_arr =  (unsigned int *)malloc(ifmaps_channel * o_hight * ifmaps_width * weight_height * sizeof(unsigned int) );

    int idx = 0;
    unsigned int o_hight_lim = (ifmaps_height - weight_height)+1;
#pragma omp parallel for collapse(4)
    for(int h=0;h<o_hight_lim;h=h+stride)
    {
        for(int i_w=0;i_w<ifmaps_width;i_w++)
        {
            for(int w_h=0;w_h<weight_height;w_h++)
            {
                for(int ch=0;ch<ifmaps_channel;ch++)
                {
                    modeling_arr[idx] = arr[ch*ifmaps_height*ifmaps_width + (w_h+h)*ifmaps_width + i_w];
                    idx++;
                }
            }
        }
        
    }

    return modeling_arr;
}


// float* readMatrixFromFile(const char* filename, int rows, int cols) {
//     FILE* file = fopen(filename, "r");
//     if (file == NULL) {
//         printf("Failed to open the file.\n");
//         return NULL;
//     }

//     // Allocate memory for the matrix
//     float* matrix = (float*)malloc(rows * cols * sizeof(float));

//     // Read data from file and store in the matrix
//     for (int i = 0; i < rows; i++) {
//         for (int j = 0; j < cols; j++) {
//             fscanf(file, "%f", &matrix[i*cols + j]);
//         }
//     }

//     // Close the file
//     fclose(file);

//     return matrix;
// }


void intToBinary(unsigned int *current_num_ptr, int *binaryArray, unsigned int start_point, unsigned int block_size, unsigned int stride) {
#pragma omp parallel for
    for (int i = 0; i < block_size; i++) {
        unsigned int current_num = *current_num_ptr;
        for (int j = 0; j < 32; j++) {
            *(binaryArray + stride * (j + i * 32) + start_point) = current_num & 1; // 32 bits
            current_num >>= 1;
        }
        current_num_ptr++; // shift to next number
    }
}

float* arr_axis_fc_modeling(unsigned int arr[], unsigned int in_features, unsigned int out_features, unsigned int ofmaps_width, unsigned int ifbias, float weight[], float bias[]) {
    float* answer_arr;
    int* tmp_arr;
//     float max_val = 0.0;
//     int answer_idx = 0;
    int size = ofmaps_width * ofmaps_width;
    tmp_arr = (int *)malloc(in_features * sizeof(int));
    answer_arr = (float *)malloc(out_features * sizeof(float));

    // 轉換成 1D 陣列
    // 計時器變數
//     clock_t start_time, end_time;
//     double total_time;

    // 開始計時
//     start_time = clock();

    int block_size = in_features / (size << 5); // 32 bits

    #pragma omp parallel for
    for (int i = 0; i < (in_features >> 5); i += block_size) {  // shift 5 bits for 32 bits
        intToBinary(&arr[i], tmp_arr, i >> 2, block_size, size);
    }

    // 結束計時
//     end_time = clock();
//     total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

//     printf("模型轉換時間: %.4f 秒\n", total_time);
    
    // 完全連接層計算
    // 開始計時
//     start_time = clock();

    #pragma omp parallel for
    for (int i = 0; i < out_features; i++) {
        float sum = 0;
        int limit = i * in_features;

        #pragma omp parallel for reduction(+:sum)
        for (int j = 0; j < in_features; j++) {
            // 檢查 tmp_arr[j] 是否為 0 或 1，並相應地調整權重（-1 或 1）
            sum += tmp_arr[j] ? weight[limit + j] : -weight[limit + j];
        }

        if (ifbias)
            answer_arr[i] = sum + bias[i];

//         printf("完全連接層輸出: %f\n", answer_arr[i]);
        
//         #pragma omp critical
//         if (answer_arr[i] > max_val) {
//             max_val = answer_arr[i];
//             answer_idx = i;
//         }
    }

    // 結束計時
//     end_time = clock();
//     total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
//     printf("完全連接層計算時間: %.4f 秒\n", total_time);

    // solfmax
    // 開始計時
//     start_time = clock();

    float sum_exp = 0.0;

    // 計算 exp
    #pragma omp parallel for reduction(+:sum_exp)
    for (int i = 0; i < out_features; i++) {
        answer_arr[i] = exp(answer_arr[i]);
        sum_exp += answer_arr[i];
    }

    // 計算 softmax
    #pragma omp parallel for
    for (int i = 0; i < out_features; i++) {
        answer_arr[i] /= sum_exp;
    }

    // 結束計時
//     end_time = clock();
//     total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
//     printf("softmax 計算時間: %.4f 秒\n", total_time);
//     printf("softmax 計算結果: \n");
//     for (int i = 0; i < out_features; i++) {
//         printf("%f\n", answer_arr[i]);
//     }
    free(tmp_arr);
    // free(answer_arr);
//     free(bias);
//     free(weight);
    // return answer_idx;
    return answer_arr;
}

int findMAX(float *arr, int size) {
    float max_val = 0.0;
    int answer_idx = 0;

    // 開始計時
//     double start_time = omp_get_wtime();

    #pragma omp parallel for
    for (int i = 0; i < size; i++) {
        #pragma omp critical
        if (arr[i] > max_val) {
            max_val = arr[i];
            answer_idx = i;
        }
    }

    // 結束計時
//     double end_time = omp_get_wtime();
//     double total_time = end_time - start_time;
//     printf("找出最大值時間: %.4f 秒\n", total_time);

    return answer_idx;
}


void free_mem(unsigned int *ptr)
{
    free(ptr);
}

/*
for ofmaps_h in range(0,o_hight,stride):
    tmp_arr = ifmaps_in[:, ofmaps_h:(ofmaps_h+weight_height),:]
    tmp_arr = tmp_arr.transpose(2,1,0)
    tmp_arr = tmp_arr.reshape(-1)
    out_arr = np.concatenate((out_arr,tmp_arr),dtype=np.uint32)
*/

// int main()
// {
//     unsigned int* file_arr;
//     file_arr = malloc( 4 * 34 * 34 * sizeof(unsigned int) );

//     char *filename = "modeling_test_in.txt";
//     FILE *fp = fopen(filename, "r");

//     if (fp == NULL)
//     {
//         printf("Error: could not open file %s", filename);
//         return 1;
//     }

//     // read one character at a time and
//     // display it to the output
//     char ch;
//     int i=0;
//     for(int x=0;x<4*34*34;x++)
//     {
//         fscanf(fp,"%u", &file_arr[x]);
//     }

//     // close the file
//     fclose(fp);

//     // for(int x=0;x<4;x++)
//     // {
//     //     for(int y=0;y<34;y++)
//     //     {
//     //         for(int z=0;z<34;z++)
//     //         {
//     //             printf("%x ",file_arr[x*34*34+y*34+z]);
//     //         }
//     //         printf("\n");
//     //     }
//     //     printf("\n");
//     // }
//     unsigned int *ret_arr;
//     ret_arr = arr_axis_modeling(file_arr,34,34,4,1,3);

//     // printf("%d",sizeof(ret_arr));
//     FILE *f = fopen("modeling_test_c_out.txt", "wb");
//     // for(int x=0;x<1;x++)
//     // {
//     //     for(int y=0;y<34;y++)
//     //     {
//     //         for(int z=0;z<34;z++)
//     //         {
//     //             fprintf(f,"%d ",ret_arr[x*34*34+y*34+z]);
//     //         }
//     //         fprintf(f,"\n");
//     //     }
//     //     fprintf(f,"\n");
//     // }
//     for(int x=0;x<13056;x++)
//     {
//         fprintf(f,"%u ",ret_arr[x]);
//     }
//     fclose(f);

//     return 0;
// }

//////////////////////////////////////////////////////////////////////////

// int main() {
//     FILE *file;
//     unsigned int *dataArray;
//     // int *answerArray;
//     int answer;
//     int numData = 0;
//     int i;
//     char strings[10][15];
//     strcpy(strings[0], "airplane");
//     strcpy(strings[1], "automobile");
//     strcpy(strings[2], "bird");
//     strcpy(strings[3], "cat");
//     strcpy(strings[4], "deer");
//     strcpy(strings[5], "dog");
//     strcpy(strings[6], "frog");
//     strcpy(strings[7], "horse");
//     strcpy(strings[8], "ship");
//     strcpy(strings[9], "truck");

//     // 開啟檔案
//     file = fopen("AXIS_ANS8.txt", "r");
//     if (file == NULL) {
//         perror("無法開啟檔案\n");
//         return 1;
//     }

//     // 確定檔案內有幾筆資料
//     while (!feof(file)) {
//         unsigned int data;
//         if (fscanf(file, "%x", &data) == 1) {
//             numData++;
//         }
//     }

//     // 回到檔案開頭
//     fseek(file, 0, SEEK_SET);

//     // 使用malloc動態配置陣列空間
//     dataArray = (unsigned int *)malloc(numData * sizeof(unsigned int));
//     if (dataArray == NULL) {
//         printf("無法配置記憶體\n");
//         return 1;
//     }

//     // 將資料讀取到陣列中
//     for (i = 0; i < numData; i++) {
//         if (fscanf(file, "%x", &dataArray[i]) != 1) {
//             printf("讀取資料失敗\n");
//             free(dataArray);
//             return 1;
//         }
//         // printf("%x\n", dataArray[i]);
//     }

//     // 關閉檔案
//     fclose(file);

//     // // 讀取weight
//     // float** matrix = readMatrixFromFile("fc_weight.txt", 10, 2048);
//     // file = fopen("fc_bias.txt", "r");
//     // if (file == NULL) {
//     //     perror("無法開啟檔案\n");
//     //     return 1;
//     // }
//     // float* bias = (float*)malloc(10 * sizeof(float));
//     // for (i = 0; i < 10; i++) {
//     //     if (fscanf(file, "%f", &bias[i]) != 1) {
//     //         printf("讀取資料失敗\n");
//     //         free(dataArray);
//     //         freeMatrix(matrix, 10);
//     //         return 1;
//     //     }
//     // }
//     // fclose(file);

//     answer = arr_axis_fc_modeling(dataArray, 2048, 10, 4, "fc_weight.txt", "fc_bias.txt");
    
//     printf("answer: %d is %s!!!\n", answer, strings[answer]);
    

//     // // 讀取txt檔案
//     // file = fopen("output_review.txt", "r");
//     // if (file == NULL) {
//     //     perror("無法開啟檔案\n");
//     //     return 1;
//     // }


//     // // 比對答案
//     // int error = 0;
//     // for (i = 0; i < 2048; i++) {
//     //     unsigned int data;
//     //     if (fscanf(file, "%d", &data) == 1) {
//     //         if (data != answerArray[i]) {
//     //             error++;
//     //         }
//     //     }
//     // }
//     // printf("output_review error: %d\n", error);
//     // fclose(file);

//     // 使用完畢後，記得釋放動態配置的記憶體
//     free(dataArray);

//     return 0;
// }
