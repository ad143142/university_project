import numpy as np
import sys

setting_function = 0
setting_ifmaps_width = 0
setting_ifmaps_hight = 0
setting_ifmaps_channel = 0
setting_weight_width = 0
setting_weight_hight = 0
setting_weight_num = 0
setting_stride = 0

weight_arr = []
weight_arr = np.array(weight_arr).astype(bool)

ifmaps_arr = []
ifmaps_arr = np.array(ifmaps_arr).astype(bool)

bias_arr = []
bias_arr = np.array(bias_arr).astype(int)


def read_setting(file_num):
    global setting_function
    global setting_ifmaps_width
    global setting_ifmaps_hight
    global setting_ifmaps_channel
    global setting_weight_width
    global setting_weight_hight
    global setting_weight_num
    global setting_stride

    file = open(file_num, "r")

    line = file.readline()
    line = int(file.readline())
    setting_function = line
    line = file.readline()
    line = int(file.readline())
    setting_ifmaps_width = line
    line = file.readline()
    line = int(file.readline())
    setting_ifmaps_hight = line
    line = file.readline()
    line = int(file.readline())
    setting_ifmaps_channel = line
    line = file.readline()
    line = int(file.readline())
    setting_weight_width = line
    line = file.readline()
    line = int(file.readline())
    setting_weight_hight = line
    line = file.readline()
    line = int(file.readline())
    setting_weight_num = line
    line = file.readline()
    line = int(file.readline())
    setting_stride = line


def weight_modeling(file_weight, setting_weight_width, setting_weight_hight, setting_weight_num, setting_ifmaps_channel,
                    weight_arr):
    for num in range(setting_weight_num):
        for width in range(setting_weight_width):
            weight = 0
            idx = 0
            for ch in range(setting_ifmaps_channel):
                for hight in range(5):
                    if ((hight < setting_weight_hight)):
                        if (file_weight[num][width][ch][hight]):
                            weight |= 1 << idx
                    idx = idx + 1
                if ((ch % 6 == 5) or (ch == setting_ifmaps_channel - 1)):
                    weight_arr = np.append(weight_arr, weight)
                    weight = 0
                    idx = 0

    np.save('weight0', weight_arr)


def bias_modeling(file_bias, setting_weight_num, bias_arr):
    for num in range(setting_weight_num):
        bias_arr = np.append(bias_arr, file_bias[num])

    np.save('bias0', bias_arr)


'''
this ifmaps modeling only in first layer
'''


def ifmaps_modeling(file_ifmaps, setting_weight_width, setting_weight_hight, setting_ifmaps_width, setting_ifmaps_hight,
                    setting_ifmaps_channel, setting_stride, ifmaps_arr):
    ofmaps_hight = int(((setting_ifmaps_width - setting_weight_width) / setting_stride + 1))
    ofmaps_width = int(((setting_ifmaps_hight - setting_weight_hight) / setting_stride + 1))

    for ofmaps_h in range(ofmaps_hight):
        for ofmaps_w in range(ofmaps_width):
            for weight_w in range(setting_weight_width):
                ifmaps = 0
                idx = 0
                for ch in range(setting_ifmaps_channel):
                    for hight in range(5):
                        if ((hight < setting_weight_hight)):
                            if (file_ifmaps[ofmaps_w + weight_w][ch][hight + ofmaps_h]):
                                ifmaps |= 1 << idx
                        idx = idx + 1
                    if ((ch % 6 == 5) or (ch == setting_ifmaps_channel - 1)):
                        ifmaps_arr = np.append(ifmaps_arr, ifmaps)
                        ifmaps = 0
                        idx = 0

    np.save('ifmaps0', ifmaps_arr)


read_setting("setting0.txt")

# file_weight = np.loadtxt('weight0.txt', dtype=bool)
# file_weight = file_weight.reshape(setting_weight_num,setting_ifmaps_channel,setting_weight_hight,setting_weight_width)
# file_weight = file_weight.transpose(0,3,1,2)
# weight_modeling(file_weight,setting_weight_width,setting_weight_hight,setting_weight_num,setting_ifmaps_channel,weight_arr)

# print(file_weight)

# weight_model = np.load('weight0.npy')
# print(weight_model)

np.set_printoptions(threshold=sys.maxsize)

# file_ifmaps = np.loadtxt('ifmaps0.txt', dtype=bool)
# file_ifmaps = file_ifmaps.reshape(setting_ifmaps_channel,setting_ifmaps_hight,setting_ifmaps_width)
# file_ifmaps = file_ifmaps.transpose(2,0,1)
# ifmaps_modeling(file_ifmaps,setting_weight_width,setting_weight_hight,setting_ifmaps_width,setting_ifmaps_hight,setting_ifmaps_channel,setting_stride,ifmaps_arr)

# print(file_ifmaps)

# ifmaps_model = np.load('ifmaps0.npy')
# print(ifmaps_model)

file_bias = np.loadtxt('bias0.txt', dtype=int)
bias_modeling(file_bias, setting_weight_num, bias_arr)

bias_model = np.load('bias0.npy')
print(bias_model)
